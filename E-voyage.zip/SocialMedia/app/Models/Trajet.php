<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Trajet extends Model
{
    protected $fillable = ['places_disponible', 
    'lieu_depart', 
    'lieu_arrivee', 
    'abr_depart', 
    'abr_arrivee', 
    'heure_depart', 
    'date_depart', 
    'prix'];
    use HasFactory;
    public function places(){
        return $this->hasMany(Place::class);
    }
    public function reservations(){
        return $this->hasMany(Reservation::class);
    }
}
