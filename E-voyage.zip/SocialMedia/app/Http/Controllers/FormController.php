<?php

namespace App\Http\Controllers;
use Srmklive\PayPal\Services\PayPal as PayPalClient;
use App\Http\Requests\Validation;
use App\Models\Place;
use App\Models\Reservation;
use App\Models\Trajet;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class FormController extends Controller
{
    
    public function store(Validation $request){
        User::create([
            'name' => $request->name,
            'numero' => $request->numero,
            'email' => $request->email,
            'password' => Hash::make($request->password),
        ]);

        return redirect()->back()->with('success', 'Vous êtes inscrit !');
    }
    public function admin(){
        return view('admin.tableau');
    }
    public function connexion(Request $request){
        $credentials = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required']
        ]);
        if(Auth::attempt($credentials)){
            $request->session()->regenerate();
            $user = auth()->user();
            if ($user->role === 'admin') {
                return redirect('/dashboard');
            }
            else{
                return view('layout.voyage');
            }
    }
}
    public function deconnexion(){
        Auth::logout();
        return redirect('/voyage');
    }
    public function index(){
        $directions = Trajet::all();
        return view('layout.voyage');
    }
    //rechercher voyage
    public function recherche(Request $request){
        $lieu_depart = $request->input('departure');
        $lieu_arrivee = $request->input('arrive');
        $date = $request->input('date');
        $place = $request->input('number');
        
        $query = Trajet::with('places')
        ->where(function ($query){
            $query->whereDate('date_depart', '>', now()->toDateString())
            ->orWhere(function ($query){
                $query->whereDate('date_depart', '=', now()->toDateString())
                ->whereTime('heure_depart', '>', now()->format('H:i:s'));
            });
        });
        

        if(!empty($lieu_depart)){
            $query->where('lieu_depart', 'LIKE', '%'. $lieu_depart .'%');
        };
        if(!empty($lieu_arrivee)){
            $query->where('lieu_arrivee', 'LIKE', '%'. $lieu_arrivee .'%');
        };
        if(!empty($date)){ 
            $query->where('date_depart', 'LIKE', '%'. $date .'%');
        };
        if(!empty($place)){
            $query->where('places_disponible', '>=', $place);
        };
        
        $trajets = $query->get();
        if($trajets){
            return view('layout.voyage', ['trajets'=> $trajets]);
        }else{
            return redirect('/voyage')->back()->with('success', 'Voyage indisponible!');
        }
        
    }

    public function traitement(Request $request){
        if (Auth()->check()){

            Reservation::create([
                'user_id' => Auth::user()->id,
                'trajet_id' => (int)$request->idtrajet, 
                'places_reserves' => strval($request->placereserve),
                'nombre_totale' => $request->nombretotale,
                'totale_prix' => $request->prixtotal,
                'dateDepart' => $request->departDD,
                'heureDepart' => $request->heureDD,
                'idPlace' => $request->idPlace,
            ]);  
           Session::put('id_trajet', $request->idtrajet) ;;
            return redirect('/facture');
        }
        else{
            return view('formulaire.connexion');
        }

    }
    public function facture(){
        
        $userR = Auth::user()->reservation();
        $reservationEnAttente = $userR->where('statu', 'attente')->get();
        $idTrajet = Session::get('id_trajet');
        $trajet = Trajet::find($idTrajet);
        return view('Layout.facture', ['reservations' => $reservationEnAttente, 'trajet' => $trajet]);
    }

    public function finalconfirmation($idReservation, $idPlaces, $idTrajet){

        DB::table('reservations')
        ->where('id', $idReservation)
        ->update(['statu' => 'reserver']);
        $place = explode(',', $idPlaces);
        $majPlace = count($place);
        $trajet = Trajet::find($idTrajet);
        $trajet->update(['places_disponible' => $trajet->places_disponible - $majPlace]);
        DB::table('places')
            ->whereIn('id', $place)
            ->update(['occupe' => 1]);
            return view('layout.successr');
        
    }
public function ts(){
    return view('layout.success');
}
    //----------------------------Paypal-----------------
    public function paye($idReservation, $idPlaces, $idTrajet, $prixReservation){
        DB::table('reservations')
        ->where('id', $idReservation)
        ->update(['statu' => 'reserver']);
        $place = explode(',', $idPlaces);
        $majPlace = count($place);
        $trajet = Trajet::find($idTrajet);
        $trajet->update(['places_disponible' => $trajet->places_disponible - $majPlace]);
        DB::table('places')
            ->whereIn('id', $place)
            ->update(['occupe' => 1]);
            return view('layout.voyage');
        // $prix = $prixReservation/4850;
        $provider = new PayPalClient;
        $provider = \PayPal::setProvider();
        $provider->setApiCredentials(config('paypal'));
        // $provider->setCurrency('MGA');
        $provider->getAccessToken();
        $provider->setCurrency('EUR');
        $response = $provider->createOrder([
            "intent" => "CAPTURE",
            "application_context" => [
                "return_url" => route('success'),
                "cancel_url" => route('success')
            ],
            "purchase_units" => [
                [
                    "amount" => [
                        "currency_code" => "EUR",
                        "value" => $prixReservation
                    ]
                ]
            ]
        ]);
        // dd($response);
        if (isset($response['id']) && $response['id']!= null){
                    return redirect()->away('https://www.sandbox.paypal.com/checkoutnow?token=4ED07822S5197430T');
        }
    }

    // public function error(){
    //     return "error";
    // }
    public function error(){
        return view('layout.success');
    }
        public function moncompte(){

        return view('layout.Moncompte');
    }

    public function annuler(Reservation $idReservation){
        $idReservation->delete();
        return view('layout.voyage');
    }
    public function IndexSignup(){
        return view('formulaire.Connexion');
    }

    public function acceuil(){
        return view('layout.acceuil');
    }
    public function natao(){
        $user = Auth::user()->id;
        $reservations = Reservation::where('user_id', $user)
        ->where('statu', 'reserver')
        ->get();
        $trajets = [];
        foreach($reservations as $reservation){
            $trajet = Trajet::find($reservation->trajet_id);

            if ($trajet){
                $trajets [] = $trajet;
            }
        }

        return view('layout.confirme', ['reservations' => $reservations, 'trajets' => $trajets]);
    }
    public function attente(){
        $user = Auth::user()->id;
        $reservations = Reservation::where('user_id', $user)
        ->where('statu', 'attente')
        ->get();
        $trajets = [];
        foreach($reservations as $reservation){
            $trajet = Trajet::find($reservation->trajet_id);

            if ($trajet){
                $trajets [] = $trajet;
            }
        }
        return view('layout.attente', ['reservations' => $reservations, 'trajets' => $trajets]);
    }
    public function voyage(){
        return view('layout.voyage');
    }

    public function dashboard(){
        $nbrU = DB::table('users')->count();
        $nbrR =  DB::table('reservations')
        ->where('statu', 'reserver')
        ->count();
        return view('admin.tableau', ['nbr' => $nbrU, 'nb' => $nbrR]);
       
    }
//---------------------------------------GERER RESERVATION------------------------------------------
    public function adminres(){
        $reservations = Reservation::with('user', 'trajet')->paginate(10);
        return view('admin.reservation', ['reservations' => $reservations]);
    }
    //supprimer un réservations
    public function suprRes(Reservation $reservationId){
        $reservationId->delete();
        return redirect()->back()->with('success', 'suppression avec succés!');
    }
//------------------------------------------GERER TRAJET--------------------------------------------
    //supprimer un trajet
    public function suprT(Trajet $trajetId){
        $trajetId->delete();
        return redirect()->back()->with('success', 'suppression avec succés!');
    }
    //afficher tout les trajets
    public function adminT(){
        $directions = Trajet::all();
        return view('admin.trajet', ['trajets' => $directions]);
    }

    //créer un nouveau trajet avec 16 place
    public function ajouteTrajet(Request $request){
        $trajet = new Trajet();
        $trajet->lieu_depart = $request->lieuD;
        $trajet->lieu_arrivee = $request->lieuA;
        $trajet->abr_depart = $request->abrD;
        $trajet->abr_arrivee = $request->abrA;
        $trajet->heure_depart = $request->hD;
        $trajet->date_depart = $request->dD;
        $trajet->prix = $request->prix;
        $trajet->places_disponible = $request->place;
        $trajet->save();

        $trajetId = $trajet->id;

        for($i=1; $i <= 16; $i++){
            $place = new Place();
            $place->trajet_id = $trajetId;
            $place->numero = $i;

            $place->save();
        }
        return redirect()->back()->with('success', 'Nouveau Trajet ajouter!');
    }

//------------------------------------------GERER USER--------------------------------------------
    public function gUser(){
        $users = User::all();
        return view('admin.user', ['users' => $users]);
    }
    public function sUser(User $iduser){
        $iduser->delete();
        return redirect()->back()->with('success', 'suppression avec succés!');
    }
    public function ajouterAdmin(Validation $request){
        User::create([
            'name' => $request->name,
            'numero' => $request->numero,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'role' => 'admin'
        ]);
        return redirect()->back()->with('success', 'Nouveau Administrateur ajouter!');
    }
    public function success(){
        return view('layout.success');
    }
}
