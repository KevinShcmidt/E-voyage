<?php

use App\Http\Controllers\Controller;
use App\Http\Controllers\FormController;
use App\Models\Post;
use App\Models\Posttable;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('layout.index');
});
// Route::get('/teste', function () {
//     return ["name" => $_GET['nom'], "age" => "10"];
// });
// Route::get('/teste', function ( Request $request ) {
//     return [ "name" => $request-> path()];
//     // return [ "name" => $request-> url()];
//     // return [ "name" => $request-> all()];
// });
// Route::get('/teste/{slug}-{id}', function (string $slug, string $id) {
//     return [ "slug" => $slug , "id" => $id ];
// });
// Route::get('post', function ( Request $request ) {
//     $post = new Posttable();
//     $post->title='titre numero 1';
//     $post->slug='article 2';
//     $post->content='lorem impus blablabla';
//     $post->save();

//     return $post;
// });
Route::middleware(['auth'])->group(function(){
    Route::get('/moncompte', [FormController::class, 'moncompte']);
    Route::get('/facture', [FormController::class, 'facture']);
    Route::get('/admin', [FormController::class, 'admin']);
    Route::get('/adminT', [FormController::class, 'adminT']);
    Route::get('/ajouteTrajet', [FormController::class, 'ajouteTrajet']);
    Route::get('/suprT-{trajetId}', [FormController::class, 'suprT']);
    Route::get('/adminres', [FormController::class, 'adminres']);
    Route::get('/dashboard', [FormController::class, 'dashboard']);
    Route::get('/supres-{reservationId}', [FormController::class, 'suprRes']);
    Route::get('/user', [FormController::class, 'gUser']);
    Route::get('/sUser-{iduser}', [FormController::class, 'sUser']);
    Route::get('/ajouterUser', [FormController::class, 'ajouterAdmin']);
    Route::get('/paye/{idReservation}-{idPlaces}-{idTrajet}-{prixReservation}', [FormController::class, 'paye']);
});
Route::post('/reserver', [FormController::class, 'traitement']);
Route::get('/error', [FormController::class, 'error'])->name('error');
Route::get('/success', [FormController::class, 'success'])->name('success');
Route::get('/recherche', [FormController::class, 'recherche']);
Route::get('/signin', [FormController::class, 'IndexSignin']);
Route::get('/login', [FormController::class, 'IndexSignup'])->name('login');
Route::get('/acceuil', [FormController::class, 'acceuil']);
Route::get('/voyage', [FormController::class, 'index']);
Route::post('/signin/store', [FormController::class, 'store']);
Route::post('/signuptohome', [FormController::class, 'connexion']);
Route::get('/edit/{idReservation}-{idPlaces}-{idTrajet}', [FormController::class, 'finalconfirmation']);
Route::get('/annuler/{idReservation}', [FormController::class, 'annuler']);
Route::get('/natao', [FormController::class, 'natao']);
Route::get('/attente', [FormController::class, 'attente']);
Route::get('/logout', [FormController::class, 'deconnexion']);

Route::get('/ts', [FormController::class, 'ts']);