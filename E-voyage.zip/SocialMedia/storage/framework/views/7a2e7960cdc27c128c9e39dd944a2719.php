<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/section2.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/aos.css')); ?>">
    
    <title>Document</title>
</head>
<body>
    <header>
        <div class="logo">
            <h2><a href="/"><span>E</span>-voyage</a></h2>
        </div>
        <div class="nav">
            <ul>  
                <li><a href="/">Accueil</a></li>
                <li><a href="/voyage">Voyage</a></li>
                <?php if(auth()->guard()->guest()): ?>
                <li><a href="/login">Se connecter</a></li>
                <?php else: ?>
                <li><a href="/moncompte">Mon compte</a></li>
                <li><a href="/logout"><i class="fas fa-exit"></i> Déconnexion</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </header>
    <section class="section1">
       <div class="global">
            <div class="texte" data-aos="fade-right"
            data-aos-anchor-placement="bottom-bottom" data-aos-duration="1000">
                <h2>MEILLEUR A MADA</h2>
                <h3>E-VOYAGE SERVICE</h3>
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Repellendus voluptas nihil provident? Ad pariatur quibusdam laudantium quas temporibus officia dignissimos quis officiis excepturi incidunt accusamus exercitationem, itaque ex aspernatur vel!</p>
                <div class="lien">
                  <a href="">SAVOIR PLUS</a>
                </div>
            </div>
            <div class="form" data-aos="zoom-in"
            data-aos-anchor-placement="bottom-bottom" data-aos-duration="1000">
                <img src="<?php echo e(asset('sary/cover.png')); ?>" alt="">
            </div>
       </div>
    </section>
    <section class="section2">
       <div class="parent">
         <div class="title">
            <h2>NOS </h2>
            <p>TARIF</p>
        </div>
          <div class="div">
            <div class="box" data-aos="fade-right"
            data-aos-anchor-placement="bottom-bottom" data-aos-duration="700">
                <div class="image">
                    <img src="<?php echo e(asset('sary/Layer-1-copy.png')); ?>" alt="">
                </div>
                <div class="titre">
                    <h2 style="color: gold;">VIP</h2>
                </div>
                <div class="para">
                    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Velit atque repudiandae adipisci voluptate fuga quo, impedit dicta molestiae incidunt modi voluptas aliquid earum rem aperiam repellendus quod enim cupiditate! Dolorem.</p>
                </div>
                <div class="button">
                    <a href="">Savoir Plus</a>
                </div>
            </div>
            <div class="box" data-aos="zoom-in"
            data-aos-anchor-placement="bottom-bottom" data-aos-duration="700">
                <div class="image">
                    <img src="<?php echo e(asset('sary/Layer-1-copy.png')); ?>" alt="">
                </div>
                <div class="titre">
                    <h2 style="color: rgb(65, 65, 65);">PREMIUM</h2>
                </div>
                <div class="para">
                    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Velit atque repudiandae adipisci voluptate fuga quo, impedit dicta molestiae incidunt modi voluptas aliquid earum rem aperiam repellendus quod enim cupiditate! Dolorem.</p>
                </div>
                <div class="button">
                    <a href="">Savoir Plus</a>
                </div>
            </div>
            <div class="box" data-aos="fade-left"
            data-aos-anchor-placement="bottom-bottom" data-aos-duration="700">
                <div class="image">
                    <img src="<?php echo e(asset('sary/lite.png')); ?>" alt="">
                </div>
                <div class="titre">
                    <h2 style="color: rgb(61, 61, 61);">STANDART</h2>
                </div>
                <div class="para">
                    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Velit atque repudiandae adipisci voluptate fuga quo, impedit dicta molestiae incidunt modi voluptas aliquid earum rem aperiam repellendus quod enim cupiditate! Dolorem.</p>
                </div>
                <div class="button">
                    <a href="">Savoir Plus</a>
                </div>
            </div>
          </div>
       </div>
    </section>
    <section class="section7">
        <div class="desc">
           <div class="logo" data-aos="fade-down" data-aos-easing="linear"
           data-aos-duration="950">
               <div class="sport">
                   <h2>E<span>Voyage</span></h2>
               </div>
           </div>
           <div class="description">
               <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Architecto commodi quaerat eveniet hic incidunt consequuntur iste exercitationem officia in. Excepturi nam earum dolorem doloribus corporis eius error nemo iusto aperiam?</p>
           </div>
        </div>
        <div class="link">
           <ul>
               <li class="top"><a href="#">support</a></li>
               <li><a href="#">facebook</a></li>
               <li><a href="#">twitter</a></li>
               <li><a href="#">google+</a></li>
               <li><a href="#">pinteres</a></li>
               <li><a href="#">linkedln</a></li>
           </ul>
           <ul>
               <li class="top"><a href="#">my account</a></li>
               <li><a href="#">sign in</a></li>
               <li><a href="#">view cart</a></li>
               <li><a href="#">my whislist</a></li>
               <li><a href="#">check out</a></li>
               <li><a href="#">track my order</a></li>
           </ul>
           <ul>
               <li class="top"><a href="#">categories</a></li>
               <li><a href="#">men</a></li>
               <li><a href="#">women</a></li>
               <li><a href="#">accessories</a></li>
               <li><a href="#">bags & shoes</a></li>
               <li><a href="#">lookbooks</a></li>
           </ul>
           <ul>
               <li class="top"><a href="#">categories</a></li>
               <li><a href="#">men</a></li>
               <li><a href="#">women</a></li>
               <li><a href="#">accessories</a></li>
               <li><a href="#">bags & shoes</a></li>
               <li><a href="#">lookbooks</a></li>
           </ul>
        </div>
   </section>
   <footer>
       <p>Copyright &copy; 2023 by <span>Kevin Rakotovao</span> All Right Reserved.</p>
   </footer>
    <script>
        let header = document.querySelector('header');
        window.addEventListener('scroll', sticky);
    
        function sticky() {
            if (scrollY > 5) {
                header.classList.add('sticky');
            } else {
                header.classList.remove('sticky')
            }
        }
    </script>
    <script src="<?php echo e(asset('js/aos.js')); ?>"></script>
    <script>AOS.init()</script>
</body>
</html><?php /**PATH C:\laragon\www\SocialMedia\resources\views/layout/index.blade.php ENDPATH**/ ?>