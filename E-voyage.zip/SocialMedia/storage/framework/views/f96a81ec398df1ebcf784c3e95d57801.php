
<?php $__env->startSection('content'); ?>
<div class="surf">
    <div class="lien">
        <h4 class="titleh" onclick=dropdown()>Mes Réservation <i class="fas fa-arrow-right"></i></h4>
        <a class="nodrop" href="/attente">En attente</a>
        <a class="nodrop" href="/natao">Confirmé</a>
    </div>
    <div class="inner">
        <h3>Les reservations confirmer</h3>
        <?php if(isset($reservations)): ?>
        <div class="attente">
            <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="grand pas">
                    <div class="petit">
                        <div class="a1"><h2>Voyage</h2></div>
                        <div class="a2"><h2>Place(s)</h2></div>
                        <div class="a3"><h2>Prix</h2></div>
                        <div class="a3"><h2>Prix Totale</h2></div>
                    </div>

                    <div class="petit">
                        <div class="a1"><p>
                            <?php $__currentLoopData = $trajets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trajet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($trajet->id === $reservation->trajet_id): ?>
                                <?php echo e($trajet->lieu_depart); ?> / <?php echo e($trajet->lieu_arrivee); ?> 
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <br><br><?php echo e(\Carbon\Carbon::parse($reservation->dateDepart)->format('l d F Y')); ?> <br><br><?php echo e($reservation->heureDepart); ?></p></div>
                        <div class="a2"><p><?php echo e($reservation->places_reserves); ?></p></div>
                        <div class="a3"><p><?php echo e($reservation->totale_prix); ?> Ar</p></div>
                        <div class="a4"><p><?php echo e($reservation->totale_prix); ?> Ar</p></div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php else: ?>
        <h2>Pas de reservation confirmer</h2>
        <?php endif; ?>
    </div>
</div> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('./layout/Moncompte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\SocialMedia\resources\views/layout/confirme.blade.php ENDPATH**/ ?>