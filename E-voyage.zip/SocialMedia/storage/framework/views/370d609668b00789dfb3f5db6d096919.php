
<?php $__env->startSection('content'); ?>
<div class="table-responsive">
  <?php if(session()->has('success')): ?>

  <P class="success">
    <?php echo e(session()->get('success')); ?>

  </P>

 <?php endif; ?>
    <div class="table-wrapper">
      <div class="table-title">
        <div class="row">
          <div class="col-xs-6">
            <h2>Gestion <b>de réservation</b></h2>
          </div>
        </div>
      </div>
      <table class="table table-striped table-hover">
        <thead>
          <tr>
            <th>Name</th>
            <th>Voyage</th>
            <th>Place réserver</th>
            <th>Date départ</th>
            <th>Heure départ</th>
            <th>Statue</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            
            <td><?php echo e($reservation->user->name); ?></td>
            <td><?php echo e($reservation->trajet->lieu_depart); ?> / <?php echo e($reservation->trajet->lieu_arrivee); ?></td>
            <td><?php echo e($reservation->places_reserves); ?></td>
            <td><?php echo e($reservation->dateDepart); ?></td>
            <td><?php echo e($reservation->heureDepart); ?></td>
            <td><?php echo e($reservation->statu); ?></td>
            
            
            <td>
              <a href="/supres-<?php echo e($reservation->id); ?>" class="delete"><i class="fas fa-trash"></i></a>
            </td>
        
          </tr>
          
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
      
    </div> 
        
  </div>
  
  
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('./admin/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\SocialMedia\resources\views/admin/reservation.blade.php ENDPATH**/ ?>