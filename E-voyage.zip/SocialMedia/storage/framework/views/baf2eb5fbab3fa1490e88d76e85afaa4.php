
<?php $__env->startSection('content'); ?>
<div class="table-responsive">
  <?php if(session()->has('success')): ?>

  <P class="success">
    <?php echo e(session()->get('success')); ?>

  </P>

 <?php endif; ?>
    <div class="table-wrapper">
      <div class="table-title">
        <div class="row">
          <div class="col-xs-6">
            <h2>Gestion <b>de Trajet</b></h2>
          </div>

          <?php if(session()->has('success')): ?>

            <P class="success">
            <?php echo e(session()->get('success')); ?>

            </P>

          <?php endif; ?>
          <div class="col-xs-6">
            <a href="#addEmployeeModal" data-bs-toggle="modal" data-bs-target="#addEmployeeModal" class="btn btn-success"><span>Ajouter nouveau</span></a>						
          </div>
        </div>
      </div>
      <table class="table table-striped table-hover">
        <thead>
          <tr>
            <th>Date</th>
            <th>Heure</th>
            <th>Départ</th>
            <th>Code Départ</th>
            <th>Arriver</th>
            <th>Code Arrivée</th>
            <th>Tarif</th>
            <th>Place disponible</th>
          </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $trajets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trajet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($trajet->date_depart); ?></td>
            <td><?php echo e($trajet->heure_depart); ?></td>
            <td><?php echo e($trajet->lieu_depart); ?></td>
            <td><?php echo e($trajet->abr_depart); ?></td>
            <td><?php echo e($trajet->lieu_arrivee); ?></td>
            <td><?php echo e($trajet->abr_arrivee); ?></td>
            <td><?php echo e($trajet->prix); ?> Ar</td>
            <td><?php echo e($trajet->places_disponible); ?></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>      
  </div>
  <div id="addEmployeeModal" class="modal fade">
    <div class="modal-dialog">
      <div class="modal-content">
        <form action="/ajouteTrajet" method="GET">
          <div class="modal-header">						
            <h4 class="modal-title">Ajouter Trajet</h4>
            <button type="button" class="close" data-bs-dismiss="modal" aria-hidden="true">&times;</button>
          </div>
          <div class="modal-body">					
            <div class="form-group">
              <label>Lieu de départ</label>
              <input type="text" class="form-control" required name="lieuD">
            </div>
            <div class="form-group">
              <label>Lieu d'arriver</label>
              <input type="text" class="form-control" required name="lieuA">
            </div>
            <div class="form-group">
              <label>Code Départ</label>
              <input type="text" class="form-control" required name="abrD">
            </div>
            <div class="form-group">
              <label>Code Arrivée</label>
              <input type="text" class="form-control" required name="abrA">
            </div>
            <div class="form-group">
              <label>Heure Départ</label>
              <input type="time" class="form-control" required name="hD">
            </div>
            <div class="form-group">
              <label>Date Départ</label>
              <input type="date" class="form-control" required name="dD">
            </div>	
            <div class="form-group">
              <label>Prix voyage</label>
              <input type="text" class="form-control" required name="prix">
            </div>	
            <div class="form-group">
              <label>Place</label>
              <input type="number" class="form-control" value="16" required name="place">
            </div>			
          </div>
          <div class="modal-footer">
            <input type="button" class="btn btn-default" data-bs-dismiss="modal" value="Annuler">
            <input type="submit" class="btn btn-success" value="Ajouter">
          </div>
        </form>
      </div>
    </div>
  </div>
  

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('./admin/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\SocialMedia\resources\views/admin/trajet.blade.php ENDPATH**/ ?>