<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('fontawesome-free-6.1.2-web/css/all.css')); ?>">
    <title>Document</title>
    <?php echo $__env->yieldContent('script'); ?>
</head>
<body>
    <header>
        <div class="logo">
            <h2><a href="/acceuil"><span>E</span>-voyage</a></h2>
        </div>
        <div class="nav">
            <ul> 
                <li><a href="/acceuil">Acceuil</a></li>
                <li><a href="/voyage">Voyage</a></li>
                <li><a href="/signup">Se connecter</a></li>
                
                <?php if(auth()->guard()->guest()): ?>
                
                <?php else: ?>
                <li><a href="/acceuil">Mon compte</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </header>
    <?php echo $__env->yieldContent('content'); ?>
</body>
</html><?php /**PATH C:\laragon\www\SocialMedia\resources\views/Layout/app.blade.php ENDPATH**/ ?>