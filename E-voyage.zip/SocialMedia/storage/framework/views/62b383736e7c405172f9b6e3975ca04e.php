

<?php $__env->startSection('content'); ?>
<section class="section1">

    <div class="connecter">

    <form action="/signuptohome" method="post">
    <?php echo method_field('post'); ?>
    <?php echo csrf_field(); ?>

        <?php if(session()->has('error')): ?>

            <p class="error"><?php echo e(session()->get('error')); ?></p>

        <?php endif; ?>
    
        <div class="email">
               
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

          <p class="error"> <?php echo e($message); ?> </p>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <label for="email">Votre email</label>
            <input type="text" name="email" id="email" value=<?php echo e(old('email')); ?>>


        </div>
        
        <div class="password">
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

          <p class="error"> <?php echo e($message); ?> </p>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <label for="password">Votre mots de pass</label>
            <input type="password" name="password" id="password">
         
        </div>
        <div class="button">
            <button type="submit">Connexion</button>
        </div>
        <a href="/signin">Creer un compte</a>
    </form>


    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\SocialMedia\resources\views/formulaire/connexion.blade.php ENDPATH**/ ?>