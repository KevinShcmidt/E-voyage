
<?php $__env->startSection('content'); ?>
<div class="table-responsive">
  <?php if(session()->has('success')): ?>

    <P class="success">
      <?php echo e(session()->get('success')); ?>

    </P>
 
   <?php endif; ?>
    <div class="table-wrapper">
     
      <div class="table-title">
        <div class="row">
          <div class="col-xs-6">
            <h2>Gestion <b>d'utilisateur</b></h2>
          </div>
          <div class="col-xs-6">
            <a href="#addEmployeeModal" data-bs-toggle="modal" data-bs-target="#addEmployeeModal" class="btn btn-success"><span>Ajouter un administrateur</span></a>						
          </div>
        </div>
      </div>
      <table class="table table-striped table-hover">
        <thead>
          <tr>
            <th>Name</th>
            <th>Numéron</th>
            <th>email</th>
            <th>Rôle</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($user->name); ?></td>
            <td><?php echo e($user->numero); ?></td>
            <td><?php echo e($user->email); ?></td>
            <td><?php echo e($user->role); ?></td>
            <td>
              <a href="#" class="edit" data-bs-toggle="modal" data-bs-target="#editEmployeeModal"><i class="fas fa-pencil-alt"></i></a>
              <a href="/sUser-<?php echo e($user->id); ?>" class="delete"><i class="fas fa-trash"></i></a>
            </td>
          </tr>
          <div id="addEmployeeModal" class="modal fade">
            <div class="modal-dialog">
              <div class="modal-content">
                <form action="/ajouterUser" method="GET">
                  <div class="modal-header">						
                    <h4 class="modal-title">Ajouter un administrateur</h4>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-hidden="true">&times;</button>
                  </div>
                  <div class="modal-body">					
                    <div class="form-group">
                      <label>Nom</label>
                      <input type="text" class="form-control" required name="name">
                    </div>
                    <div class="form-group">
                      <label>Numéro</label>
                      <input type="text" class="form-control" required name="numero">
                    </div>
                    <div class="form-group">
                      <label>Adresse Mail</label>
                      <input type="email" class="form-control" required name="email">
                    </div>
                    <div class="form-group">
                      <label>Mot de pass</label>
                      <input type="password" class="form-control" required name="password">
                    </div>
                    <div class="form-group">
                      <label>Confirmation Mot de pass</label>
                      <input type="password" class="form-control" required name="password_confirmation" placeholder="veuiller resaisir le mot de pass">
                    </div>		
                   
                  </div>
                  <div class="modal-footer">
                    <input type="button" class="btn btn-default" data-bs-dismiss="modal" value="Annuler">
                    <input type="submit" class="btn btn-success" value="Ajouter">
                  </div>
                </form>
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>      
  </div>
 
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('./admin/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\SocialMedia\resources\views/admin/user.blade.php ENDPATH**/ ?>