
<?php $__env->startSection('script'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/voyage.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<section>
    <div class="voyage">
        <h1>SELECTIONNER L'ITINERAIRE</h1>
        <form action="/recherche" method="GET" data-aos="zoom-in"
        data-aos-anchor-placement="bottom-bottom" data-aos-duration="700">
            <?php echo csrf_field(); ?>
            <?php echo method_field('GET'); ?>
            <div class="trajet">
                <?php if(isset($trajets)): ?>
                <div>
                    <label for="depart">DEPARTURE</label>

                    <select name="departure" id="depart">
                        <option value="TOAMASINA">TOAMASINA</option>
                        <option value="Antananarivo">Antananarivo</option>
                    </select>
                </div>
                <div>
                    <label for="arrive">ARRIVEE</label>
                    <select name="arrive" id="arrive">
                        <option value="TOAMASINA">TOAMASINA</option>
                        <option value="Antananarivo">Antananarivo</option>
                    </select>
                </div>
                <?php else: ?>
                <div>
                    <label for="depart">DEPART</label>

                    <select name="departure" id="depart" required>
                        <option value="Toamasina">TOAMASINA</option>
                        <option value="Antananarivo">ANTANANARIVO</option>
                        <option value="Mahajanga">Mahajanga</option>
                        <option value="Fianarantsoa">FIANARANTSOA</option>
                        <option value="Diego">DIEGO</option>
                        <option value="Tulear">TULEAR</option>
                    </select>
                </div>
                <div>
                    <label for="arrive">ARRIVEE</label>
                    <select name="arrive" id="arrive" required>
                        <option value="Toamasina">TOAMASINA</option>
                        <option value="Antananarivo">ANTANANARIVO</option>
                        <option value="Mahajanga">Mahajanga</option>
                        <option value="Fianarantsoa">FIANARANTSOA</option>
                        <option value="Diego">DIEGO</option>
                        <option value="Tulear">TULEAR</option>
                    </select>
                </div>
                <?php endif; ?>
            </div>
            <div class="nombre">
                <div>
                    <label for="date">DATE DU VOYAGE</label>
                    <input type="date" id="date" name="date" required>
                </div>
                <div>
                    <label for="number">Nombre de place(s)</label>
                    <input type="number" name="number" id="number" required placeholder="veuiller ajouter le nombre de place ici...">
                </div>
            </div>
            <button type="submit"><i class="fas fa-search"></i></button>
        </form>
        
            
    
        <div class="info" data-aos="fade-up"
        data-aos-anchor-placement="bottom-bottom" data-aos-duration="700">
            <div class="disponible">
                <span></span>
                <h2>Place dispnonible</h2>
            </div>
            <div class="occuped">
                <span></span>
                <h2>Place occupé</h2>
            </div>
            <div class="selection">
                <span></span>
                <h2>Place selectionné</h2>
            </div>
            <div class="driver">
                <span><i class="fas fa-user"></i></span>
                <h2>Chauffeur</h2>
            </div>
        </div>
        <?php if(isset($trajets)): ?>
        <div class="prix">
            <form action="/reserver" method="post">
                <?php echo method_field('POST'); ?>
                <?php echo csrf_field(); ?>
                <input type="number" id="idtrajet" name="idtrajet"  value="" hidden>
                <input type="date" id="departeDD" name="departDD" hidden>
                <input type="time" id="heureDD" name="heureDD" hidden>
                <input type="text" id="placereserve" name="placereserve" hidden>
                <input type="text" id="nombretotale" name="nombretotale" hidden>
                <input type="text" id="prixtotal" name="prixtotal" hidden>
                <input type="text" id="idPlace" name="idPlace" hidden>
                <h2>Ici pour valider votre réservation!</h2>
                <div class="total">
                    <h3>Place selectionné : <span id="cart-count"></span></h3>
                    <h3>Totale : <span id="cart-total"></span> Ar</h3>
                    <div class="valider">
                        <button class="valid" id="validate-button" onclick=valider()><span><i class="fas fa-check"></i></span> Valider</button>
                        <p class="supprimer" id="remove-button" onclick=supprimer()>supprimer</p>
                    </div>
                </div>
            </form>
        </div> 
        <?php if(session()->has('success')): ?>

         <p><?php echo e(session()->get('success')); ?></p>
        <?php else: ?>


        
        <div class="maventy">
            <?php $__currentLoopData = $trajets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trajet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <div class="voiture">
                <div class="frais">
                    <h4>Ar</h4>
                    <h4><?php echo e($trajet->prix); ?></h4>
                </div>
                <div class="departure">
                    <h2><?php echo e($trajet->abr_depart); ?></h2>
                    <p><?php echo e($trajet->lieu_depart); ?></p>
                </div>
                <div class="heure">
                    <h2>Départ : <span class="heureDepart"><?php echo e($trajet->heure_depart); ?></span></h2>
                    <span class="dateDepart" hidden><?php echo e($trajet->date_depart); ?></span>
                    <i class="fas fa-arrow-right"></i>
                    <h2>Place dispnible : <span><?php echo e($trajet->places_disponible); ?></span></h2>
                </div>
                <div class="departure">
                    <h2><?php echo e($trajet->abr_arrivee); ?></h2>
                    <p><?php echo e($trajet->lieu_arrivee); ?></p>
                </div>
                <div class="plan">
                    <table>
                        <tr>
                            <td colspan="2"><i class="fas fa-user"></td>
                                <?php if( $trajet->places[0]->occupe > 0 ): ?>
                                <td class="occupe"><?php echo e($trajet->places[0]->numero); ?></td>
                                <?php else: ?>
                                   <td class="place" onclick=reservation() data-heure=<?php echo e($trajet->heure_depart); ?> data-date=<?php echo e($trajet->date_depart); ?> data-place-id=<?php echo e($trajet->places[0]->numero); ?> data-id=<?php echo e($trajet->places[0]->id); ?> data-trajet-id=<?php echo e($trajet->id); ?> data-price=<?php echo e($trajet->prix); ?>><?php echo e($trajet->places[0]->numero); ?></td>
                                <?php endif; ?>
                                <?php if( $trajet->places[1]->occupe > 0 ): ?>
                                <td class="occupe"><?php echo e($trajet->places[1]->numero); ?></td>
                                <?php else: ?>
                                <td class="place" onclick=reservation() data-heure=<?php echo e($trajet->heure_depart); ?> data-date=<?php echo e($trajet->date_depart); ?> data-id=<?php echo e($trajet->places[1]->id); ?> data-place-id=<?php echo e($trajet->places[1]->numero); ?> data-trajet-id=<?php echo e($trajet->id); ?> data-price=<?php echo e($trajet->prix); ?>><?php echo e($trajet->places[1]->numero); ?></td>
                                <?php endif; ?>
                        </tr>
                        <tr>
                            <?php if( $trajet->places[2]->occupe > 0 ): ?>
                            <td class="occupe"><?php echo e($trajet->places[2]->numero); ?></td>
                            <?php else: ?>
                            <td class="place" onclick=reservation() data-heure=<?php echo e($trajet->heure_depart); ?> data-date=<?php echo e($trajet->date_depart); ?> data-id=<?php echo e($trajet->places[2]->id); ?> data-place-id=<?php echo e($trajet->places[2]->numero); ?> data-trajet-id=<?php echo e($trajet->id); ?> data-price=<?php echo e($trajet->prix); ?>><?php echo e($trajet->places[2]->numero); ?></td>
                            <?php endif; ?>
                            <?php if( $trajet->places[3]->occupe > 0 ): ?>
                            <td class="occupe"><?php echo e($trajet->places[3]->numero); ?></td>
                            <?php else: ?>
                            <td class="place" onclick=reservation() data-heure=<?php echo e($trajet->heure_depart); ?> data-date=<?php echo e($trajet->date_depart); ?> data-id=<?php echo e($trajet->places[3]->id); ?> data-place-id=<?php echo e($trajet->places[3]->numero); ?> data-trajet-id=<?php echo e($trajet->id); ?> data-price=<?php echo e($trajet->prix); ?>><?php echo e($trajet->places[3]->numero); ?></td>
                            <?php endif; ?>
                            <?php if( $trajet->places[4]->occupe > 0 ): ?>
                            <td class="occupe"><?php echo e($trajet->places[4]->numero); ?></td>
                            <?php else: ?>
                            <td class="place" onclick=reservation() data-heure=<?php echo e($trajet->heure_depart); ?> data-date=<?php echo e($trajet->date_depart); ?> data-id=<?php echo e($trajet->places[4]->id); ?> data-place-id=<?php echo e($trajet->places[4]->numero); ?> data-trajet-id=<?php echo e($trajet->id); ?> data-price=<?php echo e($trajet->prix); ?>><?php echo e($trajet->places[4]->numero); ?></td>
                            <?php endif; ?>
                            <?php if( $trajet->places[5]->occupe > 0 ): ?>
                            <td class="occupe"><?php echo e($trajet->places[5]->numero); ?></td>
                            <?php else: ?>
                            <td class="place" onclick=reservation() data-heure=<?php echo e($trajet->heure_depart); ?> data-date=<?php echo e($trajet->date_depart); ?> data-id=<?php echo e($trajet->places[5]->id); ?> data-place-id=<?php echo e($trajet->places[5]->numero); ?> data-trajet-id=<?php echo e($trajet->id); ?> data-price=<?php echo e($trajet->prix); ?>><?php echo e($trajet->places[5]->numero); ?></td>
                            <?php endif; ?>
                        </tr>
                        <tr>
                            <?php if( $trajet->places[6]->occupe > 0 ): ?>
                            <td class="occupe"><?php echo e($trajet->places[6]->numero); ?></td>
                            <?php else: ?>
                            <td class="place" onclick=reservation() data-heure=<?php echo e($trajet->heure_depart); ?> data-date=<?php echo e($trajet->date_depart); ?> data-id=<?php echo e($trajet->places[6]->id); ?> data-place-id=<?php echo e($trajet->places[6]->numero); ?> data-trajet-id=<?php echo e($trajet->id); ?> data-price=<?php echo e($trajet->prix); ?>><?php echo e($trajet->places[6]->numero); ?></td>
                            <?php endif; ?>
                            <?php if( $trajet->places[7]->occupe > 0 ): ?>
                            <td class="occupe"><?php echo e($trajet->places[7]->numero); ?></td>
                            <?php else: ?>
                            <td class="place" onclick=reservation() data-heure=<?php echo e($trajet->heure_depart); ?> data-date=<?php echo e($trajet->date_depart); ?> data-id=<?php echo e($trajet->places[7]->id); ?> data-place-id=<?php echo e($trajet->places[7]->numero); ?> data-trajet-id=<?php echo e($trajet->id); ?> data-price=<?php echo e($trajet->prix); ?>><?php echo e($trajet->places[7]->numero); ?></td>
                            <?php endif; ?>
                            <?php if( $trajet->places[8]->occupe > 0 ): ?>
                            <td class="occupe"><?php echo e($trajet->places[8]->numero); ?></td>
                            <?php else: ?>
                            <td class="place" colspan="2" onclick=reservation() data-heure=<?php echo e($trajet->heure_depart); ?> data-date=<?php echo e($trajet->date_depart); ?> data-id=<?php echo e($trajet->places[8]->id); ?> style="text-align: end" data-place-id=<?php echo e($trajet->places[8]->numero); ?> data-trajet-id=<?php echo e($trajet->id); ?> data-price=<?php echo e($trajet->prix); ?>><?php echo e($trajet->places[8]->numero); ?></td>
                            <?php endif; ?>
                        </tr>
                        <tr>
                            <?php if( $trajet->places[9]->occupe > 0 ): ?>
                            <td class="occupe"><?php echo e($trajet->places[9]->numero); ?></td>
                            <?php else: ?>
                            <td class="place" onclick=reservation() data-heure=<?php echo e($trajet->heure_depart); ?> data-date=<?php echo e($trajet->date_depart); ?> data-id=<?php echo e($trajet->places[9]->id); ?> data-place-id=<?php echo e($trajet->places[9]->numero); ?> data-trajet-id=<?php echo e($trajet->id); ?> data-price=<?php echo e($trajet->prix); ?>><?php echo e($trajet->places[9]->numero); ?></td>
                            <?php endif; ?>
                            <?php if( $trajet->places[10]->occupe > 0 ): ?>
                            <td class="occupe"><?php echo e($trajet->places[10]->numero); ?></td>
                            <?php else: ?>
                            <td class="place" onclick=reservation() data-heure=<?php echo e($trajet->heure_depart); ?> data-date=<?php echo e($trajet->date_depart); ?> data-id=<?php echo e($trajet->places[10]->id); ?> data-place-id=<?php echo e($trajet->places[10]->numero); ?> data-trajet-id=<?php echo e($trajet->id); ?> data-price=<?php echo e($trajet->prix); ?>><?php echo e($trajet->places[10]->numero); ?></td>
                            <?php endif; ?>
                            <?php if( $trajet->places[11]->occupe > 0 ): ?>
                            <td class="occupe"><?php echo e($trajet->places[11]->numero); ?></td>
                            <?php else: ?>
                            <td colspan="2" onclick=reservation() data-heure=<?php echo e($trajet->heure_depart); ?> data-date=<?php echo e($trajet->date_depart); ?> data-id=<?php echo e($trajet->places[11]->id); ?> style="text-align: end" class="place" data-place-id=<?php echo e($trajet->places[11]->numero); ?> data-trajet-id=<?php echo e($trajet->id); ?> data-price=<?php echo e($trajet->prix); ?>><?php echo e($trajet->places[11]->numero); ?></td>
                            <?php endif; ?>
                        <tr>
                            <?php if( $trajet->places[12]->occupe > 0 ): ?>
                            <td class="occupe"><?php echo e($trajet->places[12]->numero); ?></td>
                            <?php else: ?>
                            <td class="place" onclick=reservation() data-heure=<?php echo e($trajet->heure_depart); ?> data-date=<?php echo e($trajet->date_depart); ?> data-id=<?php echo e($trajet->places[12]->id); ?> data-place-id=<?php echo e($trajet->places[12]->numero); ?> data-trajet-id=<?php echo e($trajet->id); ?> data-price=<?php echo e($trajet->prix); ?>><?php echo e($trajet->places[12]->numero); ?></td>
                            <?php endif; ?>
                            <?php if( $trajet->places[13]->occupe > 0 ): ?>
                            <td class="occupe"><?php echo e($trajet->places[13]->numero); ?></td>
                            <?php else: ?>
                            <td class="place" onclick=reservation() data-heure=<?php echo e($trajet->heure_depart); ?> data-date=<?php echo e($trajet->date_depart); ?> data-id=<?php echo e($trajet->places[13]->id); ?> data-place-id=<?php echo e($trajet->places[13]->numero); ?> data-trajet-id=<?php echo e($trajet->id); ?> data-price=<?php echo e($trajet->prix); ?>><?php echo e($trajet->places[13]->numero); ?></td>
                            <?php endif; ?>
                            <?php if( $trajet->places[14]->occupe > 0 ): ?>
                            <td class="occupe"><?php echo e($trajet->places[14]->numero); ?></td>
                            <?php else: ?>
                            <td class="place" onclick=reservation() data-heure=<?php echo e($trajet->heure_depart); ?> data-date=<?php echo e($trajet->date_depart); ?> data-id=<?php echo e($trajet->places[14]->id); ?> data-place-id=<?php echo e($trajet->places[14]->numero); ?> data-trajet-id=<?php echo e($trajet->id); ?> data-price=<?php echo e($trajet->prix); ?>><?php echo e($trajet->places[14]->numero); ?></td>
                            <?php endif; ?>
                            <?php if( $trajet->places[15]->occupe > 0 ): ?>
                            <td class="occupe"><?php echo e($trajet->places[15]->numero); ?></td>
                            <?php else: ?>
                            <td class="place" onclick=reservation() data-heure=<?php echo e($trajet->heure_depart); ?> data-date=<?php echo e($trajet->date_depart); ?> data-id=<?php echo e($trajet->places[15]->id); ?> data-place-id=<?php echo e($trajet->places[15]->numero); ?> data-trajet-id=<?php echo e($trajet->id); ?> data-price=<?php echo e($trajet->prix); ?>><?php echo e($trajet->places[15]->numero); ?></td>
                            <?php endif; ?>
                        </tr>
                        
                    </table>
                </div>
                
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
        <?php endif; ?>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\SocialMedia\resources\views/layout/voyage.blade.php ENDPATH**/ ?>