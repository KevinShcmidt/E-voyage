
<?php $__env->startSection('script'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/voyage.css')); ?>">
<script src="<?php echo e(asset('js/reservation.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<section>
    <div class="voyage">
        <h1>SELECTIONNER L'ITINERAIRE</h1>
        <form action="/recherche" method="GET">
            <?php echo csrf_field(); ?>
            <?php echo method_field('GET'); ?>
            <div class="trajet">
                <?php if(isset($trajets)): ?>
                <div>
                    <label for="depart">DEPARTURE</label>

                    <select name="departure" id="depart">
                        <option value="TOAMASINA">TOAMASINA</option>
                        <option value="Antananarivo">Antananarivo</option>
                    </select>
                </div>
                <div>
                    <label for="arrive">ARRIVEE</label>
                    <select name="arrive" id="arrive">
                        <option value="TOAMASINA">TOAMASINA</option>
                        <option value="Antananarivo">Antananarivo</option>
                    </select>
                </div>
                <?php else: ?>
                <div>
                    <label for="depart">DEPARTURE</label>

                    <select name="departure" id="depart">
                        <?php $__currentLoopData = $directions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $direction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value=<?php echo e($direction->lieu_depart); ?>><?php echo e($direction->lieu_depart); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div>
                    <label for="arrive">ARRIVEE</label>
                    <select name="arrive" id="arrive">
                        <?php $__currentLoopData = $directions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $direction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value=<?php echo e($direction->lieu_arrivee); ?>><?php echo e($direction->lieu_arrivee); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <?php endif; ?>
            </div>
            <div class="nombre">
                <div>
                    <label for="date">DATE DU VOYAGE</label>
                    <input type="date" id="date" name="date">
                </div>
                <div>
                    <label for="number">VOYAGEUR</label>
                    <input type="number" name="number" id="number" placeholder="veuiller ajouter le nombre de place ici...">
                </div>
            </div>
            <button type="submit"><i class="fas fa-search"></i></button>
        </form>
        
            
    
        <div class="info">
            <div class="disponible">
                <span></span>
                <h2>Place dispnonible</h2>
            </div>
            <div class="occupe">
                <span></span>
                <h2>Place occupé</h2>
            </div>
            <div class="selection">
                <span></span>
                <h2>Place selectionné</h2>
            </div>
            <div class="driver">
                <span><i class="fas fa-user"></i></span>
                <h2>Chauffeur</h2>
            </div>
        </div>
        <?php if(isset($trajets)): ?>
        <div class="prix">
            <form action="/reserver" method="post" hidden>
                <?php echo method_field('POST'); ?>
                <?php echo csrf_field(); ?>
                <input type="number" id="idtrajet" name="idtrajet" hidden>
                <input type="text" id="placereserve" name="placereserve" hidden>
                <input type="text" id="nombretotale" name="nombretotale" hidden>
                <input type="text" id="prixtotal" name="prixtotal" hidden>
                <input type="text" id="idPlace" name="idPlace" hidden>
                <h2>Ici pour valider votre réservation!</h2>
                <div class="total">
                    <h3>Place selectionné : <span id="cart-count"></span></h3>
                    <h3>Totale : <span id="cart-total"></span> Ar</h3>
                    <div class="valider">
                        <button class="valid" id="validate-button" onclick=valider()><span><i class="fas fa-check"></i></span> Valider</button>
                        <p class="supprimer" id="remove-button" onclick=supprimer()>supprimer</p>
                    </div>
                </div>
            </form>
        </div> 
        
        <div class="maventy">
            <?php $__currentLoopData = $trajets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trajet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="voiture">
                <div class="frais">
                    <h4>Ar</h4>
                    <h4><?php echo e($trajet->prix); ?></h4>
                </div>
                <div class="departure">
                    <h2><?php echo e($trajet->abr_depart); ?></h2>
                    <p><?php echo e($trajet->lieu_depart); ?></p>
                </div>
                <div class="heure">
                    <h2>Départ : <span><?php echo e($trajet->heure_depart); ?></span></h2>
                    <i class="fas fa-arrow-right"></i>
                    <h2>Place dispnible : <span><?php echo e($trajet->places_disponible); ?></span></h2>
                </div>
                <div class="departure">
                    <h2><?php echo e($trajet->abr_arrivee); ?></h2>
                    <p><?php echo e($trajet->lieu_arrivee); ?></p>
                </div>
                <div class="plan">
                    <table>
                        <tr>
                            <td colspan="2"><i class="fas fa-user"></td>
                            <td class="place" onclick=reservation() data-place-id=<?php echo e($trajet->places[0]->numero); ?> data-id=<?php echo e($trajet->places[0]->id); ?> data-trajet-id=<?php echo e($trajet->id); ?> data-price=<?php echo e($trajet->prix); ?>><?php echo e($trajet->places[0]->numero); ?></td>
                            <td class="place" onclick=reservation() data-id=<?php echo e($trajet->places[1]->id); ?> data-place-id=<?php echo e($trajet->places[1]->numero); ?> data-trajet-id=<?php echo e($trajet->id); ?> data-price=<?php echo e($trajet->prix); ?>><?php echo e($trajet->places[1]->numero); ?></td>
                        </tr>
                        <tr>
                            <td class="place" onclick=reservation() data-id=<?php echo e($trajet->places[2]->id); ?> data-place-id=<?php echo e($trajet->places[2]->numero); ?> data-trajet-id=<?php echo e($trajet->id); ?> data-price=<?php echo e($trajet->prix); ?>><?php echo e($trajet->places[2]->numero); ?></td>
                            <td class="place" onclick=reservation() data-id=<?php echo e($trajet->places[3]->id); ?> data-place-id=<?php echo e($trajet->places[3]->numero); ?> data-trajet-id=<?php echo e($trajet->id); ?> data-price=<?php echo e($trajet->prix); ?>><?php echo e($trajet->places[3]->numero); ?></td>
                            <td class="place" onclick=reservation() data-id=<?php echo e($trajet->places[4]->id); ?> data-place-id=<?php echo e($trajet->places[4]->numero); ?> data-trajet-id=<?php echo e($trajet->id); ?> data-price=<?php echo e($trajet->prix); ?>><?php echo e($trajet->places[4]->numero); ?></td>
                            <td class="place" onclick=reservation() data-id=<?php echo e($trajet->places[5]->id); ?> data-place-id=<?php echo e($trajet->places[5]->numero); ?> data-trajet-id=<?php echo e($trajet->id); ?> data-price=<?php echo e($trajet->prix); ?>><?php echo e($trajet->places[5]->numero); ?></td>
                        </tr>
                        <tr>
                            <td class="place" onclick=reservation() data-id=<?php echo e($trajet->places[6]->id); ?> data-place-id=<?php echo e($trajet->places[6]->numero); ?> data-trajet-id=<?php echo e($trajet->id); ?> data-price=<?php echo e($trajet->prix); ?>><?php echo e($trajet->places[6]->numero); ?></td>
                            <td class="place" onclick=reservation() data-id=<?php echo e($trajet->places[7]->id); ?> data-place-id=<?php echo e($trajet->places[7]->numero); ?> data-trajet-id=<?php echo e($trajet->id); ?> data-price=<?php echo e($trajet->prix); ?>><?php echo e($trajet->places[7]->numero); ?></td>
                            <td class="place" colspan="2" onclick=reservation() data-id=<?php echo e($trajet->places[8]->id); ?> style="text-align: end" data-place-id=<?php echo e($trajet->places[8]->numero); ?> data-trajet-id=<?php echo e($trajet->id); ?> data-price=<?php echo e($trajet->prix); ?>><?php echo e($trajet->places[8]->numero); ?></td>
                        </tr>
                        <tr>
                            <td class="place" onclick=reservation() data-id=<?php echo e($trajet->places[9]->id); ?> data-place-id=<?php echo e($trajet->places[9]->numero); ?> data-trajet-id=<?php echo e($trajet->id); ?> data-price=<?php echo e($trajet->prix); ?>><?php echo e($trajet->places[9]->numero); ?></td>
                            <td class="place" onclick=reservation() data-id=<?php echo e($trajet->places[10]->id); ?> data-place-id=<?php echo e($trajet->places[10]->numero); ?> data-trajet-id=<?php echo e($trajet->id); ?> data-price=<?php echo e($trajet->prix); ?>><?php echo e($trajet->places[10]->numero); ?></td>
                            <td colspan="2" onclick=reservation() data-id=<?php echo e($trajet->places[11]->id); ?> style="text-align: end" class="place" data-place-id=<?php echo e($trajet->places[11]->numero); ?> data-trajet-id=<?php echo e($trajet->id); ?> data-price=<?php echo e($trajet->prix); ?>><?php echo e($trajet->places[11]->numero); ?></td>
                       
                        <tr>
                            <td class="place" onclick=reservation() data-id=<?php echo e($trajet->places[12]->id); ?> data-place-id=<?php echo e($trajet->places[12]->numero); ?> data-trajet-id=<?php echo e($trajet->id); ?> data-price=<?php echo e($trajet->prix); ?>><?php echo e($trajet->places[11]->numero); ?></td>
                            <td class="place" onclick=reservation() data-id=<?php echo e($trajet->places[13]->id); ?> data-place-id=<?php echo e($trajet->places[13]->numero); ?> data-trajet-id=<?php echo e($trajet->id); ?> data-price=<?php echo e($trajet->prix); ?>><?php echo e($trajet->places[12]->numero); ?></td>
                            <td class="place" onclick=reservation() data-id=<?php echo e($trajet->places[14]->id); ?> data-place-id=<?php echo e($trajet->places[14]->numero); ?> data-trajet-id=<?php echo e($trajet->id); ?> data-price=<?php echo e($trajet->prix); ?>><?php echo e($trajet->places[13]->numero); ?></td>
                            <td class="place" onclick=reservation() data-id=<?php echo e($trajet->places[15]->id); ?> data-place-id=<?php echo e($trajet->places[15]->numero); ?> data-trajet-id=<?php echo e($trajet->id); ?> data-price=<?php echo e($trajet->prix); ?>><?php echo e($trajet->places[14]->numero); ?></td>
                        </tr>
                        
                    </table>
                </div>
                
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
       
        <?php endif; ?>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\SocialMedia\resources\views/Layout/voyage.blade.php ENDPATH**/ ?>