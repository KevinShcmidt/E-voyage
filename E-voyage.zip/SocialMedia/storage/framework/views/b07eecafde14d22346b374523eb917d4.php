
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="facture">
    <h3>Ici pour confirmer votre réservation!</h3>
        <table class="confirmation">
            <tr class="tsipika">
                <th class="lava" style="width: 40%"><h2>Voyage</h2></th>
                <th><h2>Numéro de place(s)</h2></th>
                <th><h2>Tarif</h2></th>
                <th><h2>Net à Payer</h2></th>
            </tr>

            <tr class="ambany">
                <td class="lava"><p><?php echo e($trajet->lieu_depart); ?> / <?php echo e($trajet->lieu_arrivee); ?> <br><br><?php echo e(\Carbon\Carbon::parse($reservation->dateDepart)->format('l d F Y')); ?> <br><br><?php echo e($reservation->heureDepart); ?></p></td>
                <td><p><?php echo e($reservation->places_reserves); ?></p></td>
                <td><p><?php echo e($trajet->prix); ?> Ar</p></td>
                <td><p><?php echo e($reservation->totale_prix); ?> Ar</p></td>
            </tr>
            <tr class="cfm">
               <td><a href="/paye/<?php echo e($reservation->id); ?>-<?php echo e($reservation->idPlace); ?>-<?php echo e($trajet->id); ?>-<?php echo e($reservation->totale_prix); ?>">payer</a><a href="/edit/<?php echo e($reservation->id); ?>-<?php echo e($reservation->idPlace); ?>-<?php echo e($trajet->id); ?>">Réserver</a><a style="background-color: red" href="/annuler/<?php echo e($reservation->id); ?>">annuler</a></td>
            </tr>
        </table>
        
        
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('./layout/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\SocialMedia\resources\views/Layout/facture.blade.php ENDPATH**/ ?>