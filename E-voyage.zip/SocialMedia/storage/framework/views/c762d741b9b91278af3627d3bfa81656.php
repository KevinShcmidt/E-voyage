


<?php $__env->startSection('content'); ?>
<section class="section1">

    <?php if(session()->has('success')): ?>

        <P class="success">
            <?php echo e(session()->get('success')); ?>

        </P>

    <?php endif; ?>

    <div class="connecter">



            <form action="/signin/store" method="POST" class="inscri">
                    <?php echo method_field('post'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="name">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="error"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="name">Votre nom</label>
                    <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>">
                    </div>
                    <div class="name">
                        <?php $__errorArgs = ['numero'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="error"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <label for="numero">Votre numéro</label>
                        <input type="text" name="numero" id="numero" value="<?php echo e(old('numero')); ?>">
                        </div>
                    <div class="email">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="error"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="email">Votre email</label>
                    <input type="text" name="email" id="email" value="<?php echo e(old('email')); ?>">
                    </div>
                    <div class="password">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="error"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="password">Votre mot de pass</label>
                    <input type="password" name="password" id="password" value="<?php echo e(old('password')); ?>">
                    </div>
                    <div class="passconfirm">
                    <label for="password_confirmation">Confirmer mot de pass</label>
                    <input type="password" name="password_confirmation" id="passconfirm">
                    </div>
                    <div class="button">
                        <button type="submit">Valider</button>
                    </div>
                    <a href="/login">se connecter</a>
            </form>


    </div>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\SocialMedia\resources\views/formulaire/Inscription.blade.php ENDPATH**/ ?>