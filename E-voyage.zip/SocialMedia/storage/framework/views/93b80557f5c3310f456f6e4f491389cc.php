<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <title>E-voyage</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/success.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/aos.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('fontawesome-free-6.1.2-web/css/all.css')); ?>">
    <script src="<?php echo e(asset('js/reservation.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dropdown.js')); ?>"></script>
    <title>Document</title>
    <?php echo $__env->yieldContent('script'); ?>
</head>

<body>
    <header class="loha">
        <div class="logo">
            <h2><a href="/"><span>E</span>-voyage</a></h2>
        </div>
        <div class="nav">
            <ul>
                <li><a href="/">Accueil</a></li>
                <li><a href="/voyage">Voyage</a></li>
                <?php if(auth()->guard()->guest()): ?>
                    <li><a href="/login">Se connecter</a></li>
                <?php else: ?>
                    <li><a href="/moncompte">Mon compte</a></li>
                    <li><a href="/logout"><i class="fas fa-exit"></i> Déconnexion</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </header>
    <?php echo $__env->yieldContent('content'); ?>
    
    <script>
        let header = document.querySelector('header');
        window.addEventListener('scroll', sticky);
    
        function sticky() {
            if (scrollY > 5) {
                header.classList.add('sticky');
            } else {
                header.classList.remove('sticky')
            }
        }
    </script>
    <script src="<?php echo e(asset('js/aos.js')); ?>"></script>
    <script>AOS.init()</script>
</body>

</html>
<?php /**PATH C:\laragon\www\SocialMedia\resources\views////layout/app.blade.php ENDPATH**/ ?>