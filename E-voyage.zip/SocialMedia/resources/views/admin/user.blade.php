@extends('./admin/admin')
@section('content')
<div class="table-responsive">
  @if(session()->has('success'))

    <P class="success">
      {{  session()->get('success') }}
    </P>
 
   @endif
    <div class="table-wrapper">
     
      <div class="table-title">
        <div class="row">
          <div class="col-xs-6">
            <h2>Gestion <b>d'utilisateur</b></h2>
          </div>
          <div class="col-xs-6">
            <a href="#addEmployeeModal" data-bs-toggle="modal" data-bs-target="#addEmployeeModal" class="btn btn-success"><span>Ajouter un administrateur</span></a>						
          </div>
        </div>
      </div>
      <table class="table table-striped table-hover">
        <thead>
          <tr>
            <th>Name</th>
            <th>Numéron</th>
            <th>email</th>
            <th>Rôle</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          @foreach($users as $user)
          <tr>
            <td>{{ $user->name }}</td>
            <td>{{ $user->numero }}</td>
            <td>{{ $user->email }}</td>
            <td>{{ $user->role }}</td>
            <td>
              <a href="#" class="edit" data-bs-toggle="modal" data-bs-target="#editEmployeeModal"><i class="fas fa-pencil-alt"></i></a>
              <a href="/sUser-{{ $user->id }}" class="delete"><i class="fas fa-trash"></i></a>
            </td>
          </tr>
          <div id="addEmployeeModal" class="modal fade">
            <div class="modal-dialog">
              <div class="modal-content">
                <form action="/ajouterUser" method="GET">
                  <div class="modal-header">						
                    <h4 class="modal-title">Ajouter un administrateur</h4>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-hidden="true">&times;</button>
                  </div>
                  <div class="modal-body">					
                    <div class="form-group">
                      <label>Nom</label>
                      <input type="text" class="form-control" required name="name">
                    </div>
                    <div class="form-group">
                      <label>Numéro</label>
                      <input type="text" class="form-control" required name="numero">
                    </div>
                    <div class="form-group">
                      <label>Adresse Mail</label>
                      <input type="email" class="form-control" required name="email">
                    </div>
                    <div class="form-group">
                      <label>Mot de pass</label>
                      <input type="password" class="form-control" required name="password">
                    </div>
                    <div class="form-group">
                      <label>Confirmation Mot de pass</label>
                      <input type="password" class="form-control" required name="password_confirmation" placeholder="veuiller resaisir le mot de pass">
                    </div>		
                   
                  </div>
                  <div class="modal-footer">
                    <input type="button" class="btn btn-default" data-bs-dismiss="modal" value="Annuler">
                    <input type="submit" class="btn btn-success" value="Ajouter">
                  </div>
                </form>
              </div>
            </div>
          </div>
          @endforeach
        </tbody>
      </table>
    </div>      
  </div>
 
  @endsection
