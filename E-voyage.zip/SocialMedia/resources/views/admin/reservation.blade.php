@extends('./admin/admin')
@section('content')
<div class="table-responsive">
  @if(session()->has('success'))

  <P class="success">
    {{  session()->get('success') }}
  </P>

 @endif
    <div class="table-wrapper">
      <div class="table-title">
        <div class="row">
          <div class="col-xs-6">
            <h2>Gestion <b>de réservation</b></h2>
          </div>
        </div>
      </div>
      <table class="table table-striped table-hover">
        <thead>
          <tr>
            <th>Name</th>
            <th>Voyage</th>
            <th>Place réserver</th>
            <th>Date départ</th>
            <th>Heure départ</th>
            <th>Statue</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          @foreach ($reservations as $reservation)
          <tr>
            
            <td>{{ $reservation->user->name }}</td>
            <td>{{ $reservation->trajet->lieu_depart }} / {{ $reservation->trajet->lieu_arrivee }}</td>
            <td>{{ $reservation->places_reserves }}</td>
            <td>{{ $reservation->dateDepart }}</td>
            <td>{{ $reservation->heureDepart }}</td>
            <td>{{ $reservation->statu }}</td>
            
            
            <td>
              <a href="/supres-{{ $reservation->id }}" class="delete"><i class="fas fa-trash"></i></a>
            </td>
        
          </tr>
          
          @endforeach
        </tbody>
      </table>
      {{-- <div class="pagination">
        <ul class="pagination">
         <li class="page-item">{{ $reservations->links() }}</li> 
        </ul> 
      </div> --}}
    </div> 
        
  </div>
  
  
  @endsection
