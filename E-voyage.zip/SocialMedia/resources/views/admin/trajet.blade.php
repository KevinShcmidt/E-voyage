@extends('./admin/admin')
@section('content')
<div class="table-responsive">
  @if(session()->has('success'))

  <P class="success">
    {{  session()->get('success') }}
  </P>

 @endif
    <div class="table-wrapper">
      <div class="table-title">
        <div class="row">
          <div class="col-xs-6">
            <h2>Gestion <b>de Trajet</b></h2>
          </div>

          @if(session()->has('success'))

            <P class="success">
            {{  session()->get('success') }}
            </P>

          @endif
          <div class="col-xs-6">
            <a href="#addEmployeeModal" data-bs-toggle="modal" data-bs-target="#addEmployeeModal" class="btn btn-success"><span>Ajouter nouveau</span></a>						
          </div>
        </div>
      </div>
      <table class="table table-striped table-hover">
        <thead>
          <tr>
            <th>Date</th>
            <th>Heure</th>
            <th>Départ</th>
            <th>Code Départ</th>
            <th>Arriver</th>
            <th>Code Arrivée</th>
            <th>Tarif</th>
            <th>Place disponible</th>
          </tr>
        </thead>
        <tbody>
        @foreach($trajets as $trajet)
          <tr>
            <td>{{ $trajet->date_depart }}</td>
            <td>{{ $trajet->heure_depart }}</td>
            <td>{{ $trajet->lieu_depart }}</td>
            <td>{{ $trajet->abr_depart }}</td>
            <td>{{ $trajet->lieu_arrivee }}</td>
            <td>{{ $trajet->abr_arrivee }}</td>
            <td>{{ $trajet->prix }} Ar</td>
            <td>{{ $trajet->places_disponible }}</td>
          </tr>
        @endforeach
        </tbody>
      </table>
    </div>      
  </div>
  <div id="addEmployeeModal" class="modal fade">
    <div class="modal-dialog">
      <div class="modal-content">
        <form action="/ajouteTrajet" method="GET">
          <div class="modal-header">						
            <h4 class="modal-title">Ajouter Trajet</h4>
            <button type="button" class="close" data-bs-dismiss="modal" aria-hidden="true">&times;</button>
          </div>
          <div class="modal-body">					
            <div class="form-group">
              <label>Lieu de départ</label>
              <input type="text" class="form-control" required name="lieuD">
            </div>
            <div class="form-group">
              <label>Lieu d'arriver</label>
              <input type="text" class="form-control" required name="lieuA">
            </div>
            <div class="form-group">
              <label>Code Départ</label>
              <input type="text" class="form-control" required name="abrD">
            </div>
            <div class="form-group">
              <label>Code Arrivée</label>
              <input type="text" class="form-control" required name="abrA">
            </div>
            <div class="form-group">
              <label>Heure Départ</label>
              <input type="time" class="form-control" required name="hD">
            </div>
            <div class="form-group">
              <label>Date Départ</label>
              <input type="date" class="form-control" required name="dD">
            </div>	
            <div class="form-group">
              <label>Prix voyage</label>
              <input type="text" class="form-control" required name="prix">
            </div>	
            <div class="form-group">
              <label>Place</label>
              <input type="number" class="form-control" value="16" required name="place">
            </div>			
          </div>
          <div class="modal-footer">
            <input type="button" class="btn btn-default" data-bs-dismiss="modal" value="Annuler">
            <input type="submit" class="btn btn-success" value="Ajouter">
          </div>
        </form>
      </div>
    </div>
  </div>
  

  @endsection
