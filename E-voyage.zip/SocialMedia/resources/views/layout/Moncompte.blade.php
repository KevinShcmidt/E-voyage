@extends('./layout/app')
@section('content')

<div class="surf">
    <div class="lien">
        <h4 class="titleh" onclick=dropdown()>Mes Réservation <i class="fas fa-arrow-right"></i></h4>
        <a class="nodrop" href="/attente">En attente</a>
        <a class="nodrop" href="/natao">Confirmé</a>
    </div>
    <div class="box2">
        <h2>Découvrir autres proposition</h2>
        <div class="box222">
        <div class="box22">
            <div class="text">
                <h3>PARTEZ EN FAMILLE</h3>
                <hr>
                <p>
                    Lorem ipsum dolor sit, amet consectetur adipisicing elit. Natus nam sunt et officiis laborum doloremque iusto
                </p>
                <a href="">plus d'info</a>
            </div>
            <div class="image1">
            </div>
        </div>
        <div class="box23">
            <div class="text">
                <h3>ENVIE DE S'EVADER</h3><hr>
                <p>
                    Lorem ipsum dolor sit, amet consectetur adipisicing elit. Natus nam sunt et officiis laborum doloremque 
                </p>
                <a href="">plus d'info</a>
            </div>
            <div class="image2">
            </div>
        </div>
    </div>
    </div>
</div> 

@endsection