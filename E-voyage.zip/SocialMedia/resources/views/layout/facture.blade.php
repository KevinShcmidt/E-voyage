@extends('./layout/app')
@section('script')

@endsection
@section('content')

@foreach ($reservations as $reservation)
<div class="facture">
    <h3>Ici pour confirmer votre réservation!</h3>
        <table class="confirmation">
            <tr class="tsipika">
                <th class="lava" style="width: 40%"><h2>Voyage</h2></th>
                <th><h2>Numéro de place(s)</h2></th>
                <th><h2>Tarif</h2></th>
                <th><h2>Net à Payer</h2></th>
            </tr>

            <tr class="ambany">
                <td class="lava"><p>{{$trajet->lieu_depart}} / {{$trajet->lieu_arrivee}} <br><br>{{ \Carbon\Carbon::parse($reservation->dateDepart)->format('l d F Y') }} <br><br>{{$reservation->heureDepart}}</p></td>
                <td><p>{{ $reservation->places_reserves }}</p></td>
                <td><p>{{ $trajet->prix }} Ar</p></td>
                <td><p>{{ $reservation->totale_prix }} Ar</p></td>
            </tr>
            <tr class="cfm">
               <td><a href="/paye/{{ $reservation->id }}-{{ $reservation->idPlace }}-{{$trajet->id}}-{{ $reservation->totale_prix }}">payer</a><a href="/edit/{{ $reservation->id }}-{{ $reservation->idPlace }}-{{$trajet->id}}">Réserver</a><a style="background-color: red" href="/annuler/{{ $reservation->id }}">annuler</a></td>
            </tr>
        </table>
        
        {{-- {{ $idPlaces->id }} --}}
</div>
@endforeach
@endsection