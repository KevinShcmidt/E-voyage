@extends('./layout/Moncompte')
@section('content')
<div class="surf">
    <div class="lien">
        <h4 class="titleh" onclick=dropdown()>Mes Réservation <i class="fas fa-arrow-right"></i></h4>
        <a class="nodrop" href="/attente">En attente</a>
        <a class="nodrop" href="/natao">Confirmé</a>
    </div>
    <div class="inner">
        <h3>Les reservations confirmer</h3>
        @if(isset($reservations))
        <div class="attente">
            @foreach ($reservations as $reservation)
                <div class="grand pas">
                    <div class="petit">
                        <div class="a1"><h2>Voyage</h2></div>
                        <div class="a2"><h2>Place(s)</h2></div>
                        <div class="a3"><h2>Prix</h2></div>
                        <div class="a3"><h2>Prix Totale</h2></div>
                    </div>

                    <div class="petit">
                        <div class="a1"><p>
                            @foreach($trajets as $trajet)
                                @if($trajet->id === $reservation->trajet_id)
                                {{$trajet->lieu_depart}} / {{$trajet->lieu_arrivee}} 
                                @endif
                            @endforeach
                            <br><br>{{ \Carbon\Carbon::parse($reservation->dateDepart)->format('l d F Y') }} <br><br>{{$reservation->heureDepart}}</p></div>
                        <div class="a2"><p>{{ $reservation->places_reserves }}</p></div>
                        <div class="a3"><p>{{ $reservation->totale_prix }} Ar</p></div>
                        <div class="a4"><p>{{ $reservation->totale_prix }} Ar</p></div>
                    </div>
                </div>
            @endforeach
        </div>
        @else
        <h2>Pas de reservation confirmer</h2>
        @endif
    </div>
</div> 

@endsection