@extends('layout.app')
@section('script')
<link rel="stylesheet" href="{{ asset('css/voyage.css') }}">
{{-- <script src="{{ asset('js/reservation.js') }}"></script> --}}
@endsection
@section('content')

<section>
    <div class="voyage">
        <h1>SELECTIONNER L'ITINERAIRE</h1>
        <form action="/recherche" method="GET" data-aos="zoom-in"
        data-aos-anchor-placement="bottom-bottom" data-aos-duration="700">
            @csrf
            @method('GET')
            <div class="trajet">
                @if(isset($trajets))
                <div>
                    <label for="depart">DEPARTURE</label>

                    <select name="departure" id="depart">
                        <option value="TOAMASINA">TOAMASINA</option>
                        <option value="Antananarivo">Antananarivo</option>
                    </select>
                </div>
                <div>
                    <label for="arrive">ARRIVEE</label>
                    <select name="arrive" id="arrive">
                        <option value="TOAMASINA">TOAMASINA</option>
                        <option value="Antananarivo">Antananarivo</option>
                    </select>
                </div>
                @else
                <div>
                    <label for="depart">DEPART</label>

                    <select name="departure" id="depart" required>
                        <option value="Toamasina">TOAMASINA</option>
                        <option value="Antananarivo">ANTANANARIVO</option>
                        <option value="Mahajanga">Mahajanga</option>
                        <option value="Fianarantsoa">FIANARANTSOA</option>
                        <option value="Diego">DIEGO</option>
                        <option value="Tulear">TULEAR</option>
                    </select>
                </div>
                <div>
                    <label for="arrive">ARRIVEE</label>
                    <select name="arrive" id="arrive" required>
                        <option value="Toamasina">TOAMASINA</option>
                        <option value="Antananarivo">ANTANANARIVO</option>
                        <option value="Mahajanga">Mahajanga</option>
                        <option value="Fianarantsoa">FIANARANTSOA</option>
                        <option value="Diego">DIEGO</option>
                        <option value="Tulear">TULEAR</option>
                    </select>
                </div>
                @endif
            </div>
            <div class="nombre">
                <div>
                    <label for="date">DATE DU VOYAGE</label>
                    <input type="date" id="date" name="date" required>
                </div>
                <div>
                    <label for="number">Nombre de place(s)</label>
                    <input type="number" name="number" id="number" required placeholder="veuiller ajouter le nombre de place ici...">
                </div>
            </div>
            <button type="submit"><i class="fas fa-search"></i></button>
        </form>
        
            
    
        <div class="info" data-aos="fade-up"
        data-aos-anchor-placement="bottom-bottom" data-aos-duration="700">
            <div class="disponible">
                <span></span>
                <h2>Place dispnonible</h2>
            </div>
            <div class="occuped">
                <span></span>
                <h2>Place occupé</h2>
            </div>
            <div class="selection">
                <span></span>
                <h2>Place selectionné</h2>
            </div>
            <div class="driver">
                <span><i class="fas fa-user"></i></span>
                <h2>Chauffeur</h2>
            </div>
        </div>
        @isset($trajets)
        <div class="prix">
            <form action="/reserver" method="post">
                @method('POST')
                @csrf
                <input type="number" id="idtrajet" name="idtrajet"  value="" hidden>
                <input type="date" id="departeDD" name="departDD" hidden>
                <input type="time" id="heureDD" name="heureDD" hidden>
                <input type="text" id="placereserve" name="placereserve" hidden>
                <input type="text" id="nombretotale" name="nombretotale" hidden>
                <input type="text" id="prixtotal" name="prixtotal" hidden>
                <input type="text" id="idPlace" name="idPlace" hidden>
                <h2>Ici pour valider votre réservation!</h2>
                <div class="total">
                    <h3>Place selectionné : <span id="cart-count"></span></h3>
                    <h3>Totale : <span id="cart-total"></span> Ar</h3>
                    <div class="valider">
                        <button class="valid" id="validate-button" onclick=valider()><span><i class="fas fa-check"></i></span> Valider</button>
                        <p class="supprimer" id="remove-button" onclick=supprimer()>supprimer</p>
                    </div>
                </div>
            </form>
        </div> 
        @if(session()->has('success'))

         <p>{{ session()->get('success') }}</p>
        @else


        
        <div class="maventy">
            @foreach ($trajets as $trajet)
            
            <div class="voiture">
                <div class="frais">
                    <h4>Ar</h4>
                    <h4>{{ $trajet->prix }}</h4>
                </div>
                <div class="departure">
                    <h2>{{ $trajet->abr_depart }}</h2>
                    <p>{{ $trajet->lieu_depart }}</p>
                </div>
                <div class="heure">
                    <h2>Départ : <span class="heureDepart">{{ $trajet->heure_depart }}</span></h2>
                    <span class="dateDepart" hidden>{{ $trajet->date_depart }}</span>
                    <i class="fas fa-arrow-right"></i>
                    <h2>Place dispnible : <span>{{ $trajet->places_disponible }}</span></h2>
                </div>
                <div class="departure">
                    <h2>{{ $trajet->abr_arrivee }}</h2>
                    <p>{{ $trajet->lieu_arrivee }}</p>
                </div>
                <div class="plan">
                    <table>
                        <tr>
                            <td colspan="2"><i class="fas fa-user"></td>
                                @if( $trajet->places[0]->occupe > 0 )
                                <td class="occupe">{{ $trajet->places[0]->numero }}</td>
                                @else
                                   <td class="place" onclick=reservation() data-heure={{$trajet->heure_depart}} data-date={{$trajet->date_depart}} data-place-id={{ $trajet->places[0]->numero }} data-id={{ $trajet->places[0]->id }} data-trajet-id={{ $trajet->id }} data-price={{ $trajet->prix }}>{{ $trajet->places[0]->numero }}</td>
                                @endif
                                @if( $trajet->places[1]->occupe > 0 )
                                <td class="occupe">{{ $trajet->places[1]->numero }}</td>
                                @else
                                <td class="place" onclick=reservation() data-heure={{$trajet->heure_depart}} data-date={{$trajet->date_depart}} data-id={{ $trajet->places[1]->id }} data-place-id={{ $trajet->places[1]->numero }} data-trajet-id={{ $trajet->id }} data-price={{ $trajet->prix }}>{{ $trajet->places[1]->numero }}</td>
                                @endif
                        </tr>
                        <tr>
                            @if( $trajet->places[2]->occupe > 0 )
                            <td class="occupe">{{ $trajet->places[2]->numero }}</td>
                            @else
                            <td class="place" onclick=reservation() data-heure={{$trajet->heure_depart}} data-date={{$trajet->date_depart}} data-id={{ $trajet->places[2]->id }} data-place-id={{ $trajet->places[2]->numero }} data-trajet-id={{ $trajet->id }} data-price={{ $trajet->prix }}>{{ $trajet->places[2]->numero }}</td>
                            @endif
                            @if( $trajet->places[3]->occupe > 0 )
                            <td class="occupe">{{ $trajet->places[3]->numero }}</td>
                            @else
                            <td class="place" onclick=reservation() data-heure={{$trajet->heure_depart}} data-date={{$trajet->date_depart}} data-id={{ $trajet->places[3]->id }} data-place-id={{ $trajet->places[3]->numero }} data-trajet-id={{ $trajet->id }} data-price={{ $trajet->prix }}>{{ $trajet->places[3]->numero }}</td>
                            @endif
                            @if( $trajet->places[4]->occupe > 0 )
                            <td class="occupe">{{ $trajet->places[4]->numero }}</td>
                            @else
                            <td class="place" onclick=reservation() data-heure={{$trajet->heure_depart}} data-date={{$trajet->date_depart}} data-id={{ $trajet->places[4]->id }} data-place-id={{ $trajet->places[4]->numero }} data-trajet-id={{ $trajet->id }} data-price={{ $trajet->prix }}>{{ $trajet->places[4]->numero }}</td>
                            @endif
                            @if( $trajet->places[5]->occupe > 0 )
                            <td class="occupe">{{ $trajet->places[5]->numero }}</td>
                            @else
                            <td class="place" onclick=reservation() data-heure={{$trajet->heure_depart}} data-date={{$trajet->date_depart}} data-id={{ $trajet->places[5]->id }} data-place-id={{ $trajet->places[5]->numero }} data-trajet-id={{ $trajet->id }} data-price={{ $trajet->prix }}>{{ $trajet->places[5]->numero }}</td>
                            @endif
                        </tr>
                        <tr>
                            @if( $trajet->places[6]->occupe > 0 )
                            <td class="occupe">{{ $trajet->places[6]->numero }}</td>
                            @else
                            <td class="place" onclick=reservation() data-heure={{$trajet->heure_depart}} data-date={{$trajet->date_depart}} data-id={{ $trajet->places[6]->id }} data-place-id={{ $trajet->places[6]->numero }} data-trajet-id={{ $trajet->id }} data-price={{ $trajet->prix }}>{{ $trajet->places[6]->numero }}</td>
                            @endif
                            @if( $trajet->places[7]->occupe > 0 )
                            <td class="occupe">{{ $trajet->places[7]->numero }}</td>
                            @else
                            <td class="place" onclick=reservation() data-heure={{$trajet->heure_depart}} data-date={{$trajet->date_depart}} data-id={{ $trajet->places[7]->id }} data-place-id={{ $trajet->places[7]->numero }} data-trajet-id={{ $trajet->id }} data-price={{ $trajet->prix }}>{{ $trajet->places[7]->numero }}</td>
                            @endif
                            @if( $trajet->places[8]->occupe > 0 )
                            <td class="occupe">{{ $trajet->places[8]->numero }}</td>
                            @else
                            <td class="place" colspan="2" onclick=reservation() data-heure={{$trajet->heure_depart}} data-date={{$trajet->date_depart}} data-id={{ $trajet->places[8]->id }} style="text-align: end" data-place-id={{ $trajet->places[8]->numero }} data-trajet-id={{ $trajet->id }} data-price={{ $trajet->prix }}>{{ $trajet->places[8]->numero }}</td>
                            @endif
                        </tr>
                        <tr>
                            @if( $trajet->places[9]->occupe > 0 )
                            <td class="occupe">{{ $trajet->places[9]->numero }}</td>
                            @else
                            <td class="place" onclick=reservation() data-heure={{$trajet->heure_depart}} data-date={{$trajet->date_depart}} data-id={{ $trajet->places[9]->id }} data-place-id={{ $trajet->places[9]->numero }} data-trajet-id={{ $trajet->id }} data-price={{ $trajet->prix }}>{{ $trajet->places[9]->numero }}</td>
                            @endif
                            @if( $trajet->places[10]->occupe > 0 )
                            <td class="occupe">{{ $trajet->places[10]->numero }}</td>
                            @else
                            <td class="place" onclick=reservation() data-heure={{$trajet->heure_depart}} data-date={{$trajet->date_depart}} data-id={{ $trajet->places[10]->id }} data-place-id={{ $trajet->places[10]->numero }} data-trajet-id={{ $trajet->id }} data-price={{ $trajet->prix }}>{{ $trajet->places[10]->numero }}</td>
                            @endif
                            @if( $trajet->places[11]->occupe > 0 )
                            <td class="occupe">{{ $trajet->places[11]->numero }}</td>
                            @else
                            <td colspan="2" onclick=reservation() data-heure={{$trajet->heure_depart}} data-date={{$trajet->date_depart}} data-id={{ $trajet->places[11]->id }} style="text-align: end" class="place" data-place-id={{ $trajet->places[11]->numero }} data-trajet-id={{ $trajet->id }} data-price={{ $trajet->prix }}>{{ $trajet->places[11]->numero }}</td>
                            @endif
                        <tr>
                            @if( $trajet->places[12]->occupe > 0 )
                            <td class="occupe">{{ $trajet->places[12]->numero }}</td>
                            @else
                            <td class="place" onclick=reservation() data-heure={{$trajet->heure_depart}} data-date={{$trajet->date_depart}} data-id={{ $trajet->places[12]->id }} data-place-id={{ $trajet->places[12]->numero }} data-trajet-id={{ $trajet->id }} data-price={{ $trajet->prix }}>{{ $trajet->places[12]->numero }}</td>
                            @endif
                            @if( $trajet->places[13]->occupe > 0 )
                            <td class="occupe">{{ $trajet->places[13]->numero }}</td>
                            @else
                            <td class="place" onclick=reservation() data-heure={{$trajet->heure_depart}} data-date={{$trajet->date_depart}} data-id={{ $trajet->places[13]->id }} data-place-id={{ $trajet->places[13]->numero }} data-trajet-id={{ $trajet->id }} data-price={{ $trajet->prix }}>{{ $trajet->places[13]->numero }}</td>
                            @endif
                            @if( $trajet->places[14]->occupe > 0 )
                            <td class="occupe">{{ $trajet->places[14]->numero }}</td>
                            @else
                            <td class="place" onclick=reservation() data-heure={{$trajet->heure_depart}} data-date={{$trajet->date_depart}} data-id={{ $trajet->places[14]->id }} data-place-id={{ $trajet->places[14]->numero }} data-trajet-id={{ $trajet->id }} data-price={{ $trajet->prix }}>{{ $trajet->places[14]->numero }}</td>
                            @endif
                            @if( $trajet->places[15]->occupe > 0 )
                            <td class="occupe">{{ $trajet->places[15]->numero }}</td>
                            @else
                            <td class="place" onclick=reservation() data-heure={{$trajet->heure_depart}} data-date={{$trajet->date_depart}} data-id={{ $trajet->places[15]->id }} data-place-id={{ $trajet->places[15]->numero }} data-trajet-id={{ $trajet->id }} data-price={{ $trajet->prix }}>{{ $trajet->places[15]->numero }}</td>
                            @endif
                        </tr>
                        {{-- @endforeach --}}
                    </table>
                </div>
                {{-- @empty
                <p>{{ "désolé aucun trajet pour cette date" }}</p> --}}
            </div>
            @endforeach
        </div>
        @endif
        @endisset
    </div>
</section>

@endsection