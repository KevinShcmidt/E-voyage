@extends('../layout/app')

@section('content')
<section class="section1">

    <div class="connecter">

    <form action="/signuptohome" method="post">
    @method('post')
    @csrf

        @if(session()->has('error'))

            <p class="error">{{ session()->get('error') }}</p>

        @endif
    
        <div class="email">
               
        @error('email')

          <p class="error"> {{ $message }} </p>

        @enderror
            <label for="email">Votre email</label>
            <input type="text" name="email" id="email" value={{ old('email') }}>


        </div>
        
        <div class="password">
        @error('password')

          <p class="error"> {{ $message }} </p>

        @enderror
            <label for="password">Votre mots de pass</label>
            <input type="password" name="password" id="password">
         
        </div>
        <div class="button">
            <button type="submit">Connexion</button>
        </div>
        <a href="/signin">Creer un compte</a>
    </form>


    </div>
</section>
@endsection