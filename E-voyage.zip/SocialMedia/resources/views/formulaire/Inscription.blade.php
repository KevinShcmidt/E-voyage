@extends('../layout/app')


@section('content')
<section class="section1">

    @if(session()->has('success'))

        <P class="success">
            {{  session()->get('success') }}
        </P>

    @endif

    <div class="connecter">



            <form action="/signin/store" method="POST" class="inscri">
                    @method('post')
                    @csrf
                    <div class="name">
                    @error('name')
                    <p class="error">{{ $message }}</p>
                    @enderror
                    <label for="name">Votre nom</label>
                    <input type="text" name="name" id="name" value="{{ old('name') }}">
                    </div>
                    <div class="name">
                        @error('numero')
                        <p class="error">{{ $message }}</p>
                        @enderror
                        <label for="numero">Votre numéro</label>
                        <input type="text" name="numero" id="numero" value="{{ old('numero') }}">
                        </div>
                    <div class="email">
                    @error('email')
                    <p class="error">{{ $message }}</p>
                    @enderror
                    <label for="email">Votre email</label>
                    <input type="text" name="email" id="email" value="{{ old('email') }}">
                    </div>
                    <div class="password">
                    @error('password')
                    <p class="error">{{ $message }}</p>
                    @enderror
                    <label for="password">Votre mot de pass</label>
                    <input type="password" name="password" id="password" value="{{ old('password') }}">
                    </div>
                    <div class="passconfirm">
                    <label for="password_confirmation">Confirmer mot de pass</label>
                    <input type="password" name="password_confirmation" id="passconfirm">
                    </div>
                    <div class="button">
                        <button type="submit">Valider</button>
                    </div>
                    <a href="/login">se connecter</a>
            </form>


    </div>

</section>
@endsection