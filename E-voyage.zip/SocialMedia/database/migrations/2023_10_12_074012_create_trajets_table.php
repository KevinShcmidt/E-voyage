<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('trajets', function (Blueprint $table) {
            $table->id();
            $table->string('lieu_depart');
            $table->string('lieu_arrivee');
            $table->string('abr_depart');
            $table->string('abr_arrivee');
            $table->time('heure_depart');
            $table->date('date_depart');
            $table->decimal('prix', 6, 3);
            $table->integer('places_disponible');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('trajets');
    }
};
