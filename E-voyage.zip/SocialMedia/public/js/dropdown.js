


// function dropdown(){
//     const titleh = document.querySelector('.lien');
//     const drop = document.querySelectorAll('.drop');

//     titleh.addEventListener('click', () =>{
//         drop.forEach(dro => {
//             dro.classList.add('nodrop');
//         });
        
//     })
// }
