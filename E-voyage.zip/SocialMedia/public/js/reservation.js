// Variable pour stocker les places sélectionnées
const selectedPlaces = []; 

    //extrare le idPlace
    // document.getElementById('idPlace').value = idPlaceArray;
    // 
    
function reservation() {
    
// Écouteurs d'événements pour les clics sur les places
    document.querySelectorAll('.place').forEach(place => {
    place.addEventListener('click', () =>{
        
        console.log(selectedPlaces);
        // Obtenir le numéro de la place, id trajet et le prix depuis les attributs HTML
        const placeNumber = place.getAttribute('data-place-id');
        const idPlace = place.getAttribute('data-id');
        const heureH = place.getAttribute('data-heure');
        const departure = place.getAttribute('data-date');
        const placePrice = parseFloat(place.getAttribute('data-price'));
        const idTrajet = place.getAttribute('data-trajet-id');
        
        
        const affichePanier = document.querySelector('.prix');
        affichePanier.classList.add('afficher');
        // Vérifier si la place est déjà sélectionnée
        const index = selectedPlaces.findIndex(item => item.placeNumber == placeNumber);
        if (index === -1) {
        // Ajouter la place à la sélection
        selectedPlaces.push({placePrice, placeNumber, idTrajet, idPlace, heureH, departure});
        place.classList.add('selected'); // Mettre en surbrillance visuellement la place
        } else {
        // Supprimer la place de la sélection
        selectedPlaces.splice(index, 1);
        place.classList.remove('selected'); // Annuler la surbrillance
        }
        updateCart()
    });
});
}
function updateCart() {
    // Calculer le nombre de places sélectionnées
    const numSelected = selectedPlaces.length;
    
    // Calculer le prix total
    const totalAmount = selectedPlaces.reduce((total, place) => total + place.placePrice, 0);
    // const totalAmountint = parseInt(totalAmount);
    // Mettre à jour l'interface du panier
    document.getElementById('cart-count').textContent = numSelected;
    document.getElementById('nombretotale').value = numSelected;
    document.getElementById('cart-total').textContent = totalAmount; 
   
    //extraire le placeNumber dans selectedPlace
    const numeroPlaceArray = selectedPlaces.map(item => item.placeNumber);
    const numeroPlace = numeroPlaceArray.join(',');
    //ajouter dans value
    document.getElementById('placereserve').value = numeroPlace;
    //recuperer le premier id 
    const idTrajetinArray = selectedPlaces[0].idTrajet;
    document.getElementById('idtrajet').value = idTrajetinArray;

    //recuperer idPlace
    const idPlaceArray = selectedPlaces.map(item => item.idPlace);
    const idPlace = idPlaceArray.join(',');
    document.getElementById('idPlace').value = idPlace;
    const totalAmountint = totalAmount;
    document.getElementById('prixtotal').value = totalAmountint;
    console.log(numeroPlaceArray);
    console.log(selectedPlaces);
    const dateD = selectedPlaces[0].departure;
    document.getElementById('departeDD').value = dateD;
    const heureD = selectedPlaces[0].heureH;
    document.getElementById('heureDD').value = heureD;
    // Afficher le prix total avec 2 décimales
    }
    // Écouteur d'événement pour le bouton "Valider"
    function valider() {
        document.getElementById('validate-button').addEventListener('click', () => {
            // Envoyer les places sélectionnées au serveur pour l'insertion dans la base de données (par exemple, via une requête AJAX)
            // Une fois l'insertion réussie, vous pouvez réinitialiser le panier
            selectedPlaces.length = 0; // Effacer le panier
            
            updateCart(); // Mettre à jour l'interface utilisateur
            });
        
    }
    
    // Écouteur d'événement pour le bouton "Supprimer"
    
    function supprimer(){
        document.getElementById('remove-button').addEventListener('click', () => {
            // Réinitialiser le panier sans effectuer l'insertion
            selectedPlaces.length = 0; // Effacer le panier
            updateCart(); // Mettre à jour l'interface utilisateur
            });
    }

  

